package AoC2022.Day1;

import java.util.Scanner;

public class CalorieCounting1 {
   public static void main(String[] args) {
      Scanner stdin = new Scanner(System.in);
      int mostCals = 0;
      int inventory = 0;
      while (stdin.hasNextLine()) {
         String cals = stdin.nextLine();
         if (cals.equals("")) {
            if (inventory > mostCals) {
               mostCals = inventory;
            }
            inventory = 0;
            continue;
         } else {
            int digit = 1;
            for (int i = cals.length() - 1; i >= 0; i--) {
               inventory += ((cals.charAt(i) - '0') * digit);
               digit *= 10;
            }
         }
      }
      System.out.print(mostCals);
   }
}