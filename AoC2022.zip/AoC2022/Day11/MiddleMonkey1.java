package AoC2022.Day11;

import java.util.Scanner;

import java.util.StringTokenizer;

public class MiddleMonkey1 {
   public static void main(String[] args) {
      Scanner stdin = new Scanner(System.in);
      int lineNumber = 1;
      Monkey[] monkeys = new Monkey[7];
      while (stdin.hasNextLine()) {
         if (lineNumber == 1) {
            StringTokenizer st = new StringTokenizer(stdin.nextLine());
            for (int i = 0; i <= 6; i++) {
               if (monkeys[i] == null) {
                  monkeys[i] = new Monkey(st.countTokens() - 2);
               }
            }
            lineNumber++;
         } else if (lineNumber == 2) {
            lineNumber++;
         } else if (lineNumber == 3) {
            lineNumber++;
         } else if (lineNumber == 4) {
            lineNumber++;
         } else if (lineNumber == 5) {
            lineNumber++;
         } else if (lineNumber == 6) {
            lineNumber++;
         } else {
            stdin.nextLine();
            lineNumber = 1;
            continue;
         }
      }
   }
}

class Monkey {
   String[] items;
   String operation;
   int itemsHeld;
   int divisibleBy;

   public Monkey(int startingItems) {
      this.itemsHeld = startingItems;
   }
}