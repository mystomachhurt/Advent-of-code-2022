package AoC2022.Day12;

import java.util.Scanner;

public class HillClimbing {
   public static void main(String[] args) {
      Scanner stdin = new Scanner(System.in);
      String[] heightMap = new String[41];
      int stepsTaken = 0;
      for (int i = 0; i <= heightMap.length - 1; i++) {
         heightMap[i] = stdin.nextLine();
      }
      int rows = heightMap[0].length();
      System.out.print(stepsTaken);
   }
}