package AoC2022.Day25;

import java.util.Scanner;

public class FullOfHotAir2 {
   public static void main(String[] args) {
      //get 49 stars by doing both of the puzzles for each day
   }
}