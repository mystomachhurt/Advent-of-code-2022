package AoC2022.Day7;

import java.util.Scanner;

public class NoSpaceLeft1 {
   public static void main(String[] args) {
      Scanner stdin = new Scanner(System.in);
      while (stdin.hasNextLine()) {
         
      }
      stdin.close();
   }
}

class Directory {
   int size;
   Directory parent;
   
   
   public Directory(Directory parent) {
      this.size = 0;
      this.parent = parent;
   }
}